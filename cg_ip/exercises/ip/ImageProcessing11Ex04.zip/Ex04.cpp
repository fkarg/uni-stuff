/**
 * Image Processing and Computer Graphics
 *
 * Exercise 4: Fourier Features
 */

/// System/STL
#include <cstdlib>    /// EXIT_SUCCESS
#include <fstream>    /// std::ifstream
#include <iostream>   /// std::cout 
#include <stdexcept>  /// std::runtime_error
#include <string>
#include <vector>
/// Local files
#include "CMatrix.h"
#include "CTensor.h"
#include "CFilter.h"

int main(int argc, char** args) 
{  
  /// Tell the compiler not to throw warnings for unused variables
  /// (Remove these lines if you want to use command line arguments)
  (void)argc;
  (void)args;

  /// Ground truth class annotation for all images
  std::vector<int> image_classes;
  /// Filenames of all images
  std::vector<std::string> image_filenames;

  /// Parse list of images and print some info
  {
    const std::string list_of_all_images = "./list_of_all_images.txt";
    std::cout << "Parsing image list...\n" << std::flush;
    int new_class;
    std::string new_image_file;
    /// Open info file for reading
    std::ifstream in(list_of_all_images);
    if (not in.is_open() or not in.good())
      throw std::runtime_error("Could not open " + list_of_all_images);      
    /// Parse file, one line at a time
    while (true) {
      in >> new_class >> new_image_file;
      /// If the EOF bit is set, the stream has read past the file
      /// end and the last values are invalid.
      if (in.eof())
        break;
      image_classes.push_back(new_class);
      image_filenames.push_back(new_image_file);
    }
    in.close();
    std::cout << "...done. Found " << image_classes.size() 
              << " images from " << image_classes.back() 
              << " classes.\n";
  }


  /**
   * EXERCISE 4
   */

  return EXIT_SUCCESS;
}

