//
//  iOS_main.h
//  01_project_skeleton
//
//  Created by Sid on 17/03/13.
//  Copyright (c) 2013 whackylabs. All rights reserved.
//

#ifndef _1_project_skeleton_iOS_main_h
#define _1_project_skeleton_iOS_main_h

// third-party libraries
#include <glm/glm.hpp>

extern glm::vec2 SCREEN_SIZE;
int iOS_main();
void Render();
#endif
